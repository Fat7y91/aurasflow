import os
from flask import Flask, render_template, request, session, redirect, send_from_directory
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()
deepseek_key = os.getenv("DEEPSEEK_API_KEY")

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "default_secret_123")

translations = {
    'ar': {
        'title': 'مصمم المنشورات بالذكاء الاصطناعي',
        'placeholder': 'اكتب وصف التصميم المطلوب...',
        'button': '<i class="fas fa-magic"></i> أنشئ التصميم',
        'result_title': '✅ التصميم الجاهز:',
        'switch_ar': 'العربية',
        'switch_en': 'الإنجليزية',
        'footer': 'تم التطوير بحب باستخدام Aurasflow & DeepSeek'
    },
    'en': {
        'title': 'AI Design Generator Pro',
        'placeholder': 'Enter your design description...',
        'button': '<i class="fas fa-magic"></i> Generate Design',
        'result_title': '✅ Your Design:',
        'switch_ar': 'Arabic',
        'switch_en': 'English',
        'footer': 'Crafted with ♥ using Aurasflow & DeepSeek'
    }
}

def get_current_language():
    if 'lang' in session:
        return session['lang']
    browser_lang = request.accept_languages.best_match(['ar', 'en'])
    return browser_lang if browser_lang else 'ar'

@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

@app.route('/')
def home():
    lang = get_current_language()
    return render_template('index.html', lang=lang, translations=translations)

@app.route('/set_lang/<language>')
def set_language(language):
    if language in ['ar', 'en']:
        session['lang'] = language
    return redirect('/')

@app.route('/generate', methods=['POST'])
def generate_design():
    lang = get_current_language()
    user_prompt = request.form['prompt']
    full_prompt = f"أجب باللغة العربية فقط: {user_prompt}" if lang == 'ar' else f"Answer in English only: {user_prompt}"

    api_key_value = os.getenv("DEEPSEEK_API_KEY")
    if not api_key_value:
        error_msg = "❌ خطأ: لم يتم تعيين مفتاح API" if lang == 'ar' else "❌ Error: API key not set"
        return render_template('index.html', result=error_msg, lang=lang, translations=translations, prompt=user_prompt)

    client = OpenAI(api_key=api_key_value, base_url="https://api.deepseek.com/v1")

    try:
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=[{"role": "user", "content": full_prompt}],
            max_tokens=2000
        )
        result = response.choices[0].message.content
    except Exception as e:
        result = f"🚫 خطأ: {str(e)}" if lang == 'ar' else f"🚫 Error: {str(e)}"

    return render_template('index.html', result=result, prompt=user_prompt, lang=lang, translations=translations)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
